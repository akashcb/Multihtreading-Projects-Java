package actors;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		 String l = "asfdfdasdaaaaaaaaf " ;
		String[] arr = l.split("a");
		System.out.println(arr);
		for(String s : arr)
		{
			if(s.length() >= 1)
				System.out.println(s);
		}
			
		
	}

}
