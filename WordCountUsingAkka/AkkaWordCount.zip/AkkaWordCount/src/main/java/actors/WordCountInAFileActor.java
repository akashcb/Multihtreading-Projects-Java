package actors;

import akka.actor.UntypedActor;

/**
 * this actor reads the file line by line and sends them to
 * {@code WordsInLineActor} to count the words in line. Upon geting the results,
 * It sends the result to it's parent actor {@code WordCount}
 * 
 * @author akashnagesh
 *
 */
public class WordCountInAFileActor extends UntypedActor {

	public WordCountInAFileActor() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onReceive(Object msg) throws Throwable {

	}

}
