package actors;

import akka.actor.UntypedActor;

/**
 * This actor counts number words in a single line
 * 
 * @author akashnagesh
 *
 */
public class WordsInLineActor extends UntypedActor {

	@Override
	public void onReceive(Object msg) throws Throwable {

	}
}
