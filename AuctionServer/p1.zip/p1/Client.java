package p1;

public interface Client extends Runnable
{
	String name();
}